// src/components/PasswordResetForm.jsx

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../pages/PasswordResetPage/PasswordResetPage.css';

const PasswordResetForm = ({ onResetSuccess }) => {
  const navigate = useNavigate();
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCheckIcon, setShowCheckIcon] = useState(false);

  // 두 입력값이 모두 있을 때만 체크
  const isMatch = confirmPassword && newPassword === confirmPassword;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newPassword || !confirmPassword) {
      alert('모든 항목을 입력해주세요.');
      return;
    }
    if (newPassword !== confirmPassword) {
      alert('비밀번호가 일치하지 않습니다.');
      return;
    }
    // 실제 재설정 로직 또는 API 호출
    onResetSuccess();
  };

  return (
    <form onSubmit={handleSubmit} className="form-password-reset">
      {/* 새 비밀번호 입력 */}
      <input
        type="password"
        placeholder="새 비밀번호 입력"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
        required
      />
      {/* 비밀번호 재입력 (체크 아이콘 포함) */}
      <div style={{ position: "relative" }}>
        <input
          type="password"
          placeholder="비밀번호 재입력"
          value={confirmPassword}
          onChange={e => {
            setConfirmPassword(e.target.value);
            setShowCheckIcon(true);
          }}
          required
          style={{ paddingRight: "40px" }}  // 오른쪽에 아이콘 공간 확보
        />
        {showCheckIcon && (
          <span className={`check-icon ${isMatch ? 'match' : 'nomatch'}`}
            style={{
              position: 'absolute',
              top: '50%',
              right: '12px',
              transform: 'translateY(-50%)',
              fontSize: '1.2rem',
            }}
          >
            {isMatch ? '✓' : '✕'}
          </span>
        )}
      </div>
      {/* 확인 버튼 */}
      <button type="submit" className="btn-reset">
        확인
      </button>
    </form>
  );
};

export default PasswordResetForm;
