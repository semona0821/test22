// src/pages/PasswordResetPage/PasswordResetPage.jsx

import React from 'react';
import PasswordResetForm from '../../components/PasswordResetForm.jsx';
import '../PasswordResetPage/PasswordResetPage.css';

const PasswordResetPage = () => {
  const onResetSuccess = () => {
    alert('비밀번호가 성공적으로 변경되었습니다.');
    // 예시: 변경 후 로그인 페이지로 이동
    window.location.href = '/login';
  };

  return (
    <div className="password-reset-page-wrapper">
      <div className="password-reset-card">
        <h2 className="password-reset-title">비밀번호 재설정</h2>
        <PasswordResetForm onResetSuccess={onResetSuccess} />
      </div>
    </div>
  );
};

export default PasswordResetPage;
